import os
import librosa
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import load_model

MODEL_PATH = 'speaker_embedding_model.h5'
AUDIO_DIR = '/Users/apple/Desktop/speaker_model/audio_data'
OUTPUT_EMBEDDINGS = 'reference_embeddings.npy'
OUTPUT_LABELS = 'reference_labels.npy'

SAMPLE_RATE = 16000
DURATION = 6  # seconds
TARGET_SHAPE = (128, 128)

# Load the model
model = load_model(MODEL_PATH, compile=False)
assert model.input_shape[-3:] == (128, 128, 1), f"Model expects shape (128, 128, 1), got {model.input_shape[-3:]}"

def preprocess_audio(file_path):
    signal, sr = librosa.load(file_path, sr=SAMPLE_RATE)
    required_len = SAMPLE_RATE * DURATION
    if len(signal) < required_len:
        signal = np.pad(signal, (0, required_len - len(signal)))
    else:
        signal = signal[:required_len]

    mel = librosa.feature.melspectrogram(y=signal, sr=sr, n_fft=1024, hop_length=256, n_mels=128)
    mel_db = librosa.power_to_db(mel, ref=np.max)

    # Avoid division by zero in normalization
    mel_min = mel_db.min()
    mel_max = mel_db.max()
    mel_range = mel_max - mel_min if mel_max > mel_min else 1e-9
    mel_norm = (mel_db - mel_min) / mel_range

    mel_expanded = np.expand_dims(mel_norm, axis=-1)  # (128, time, 1)
    mel_resized = tf.image.resize(mel_expanded, TARGET_SHAPE).numpy()  # (128, 128, 1)
    return np.expand_dims(mel_resized, axis=0)  # (1, 128, 128, 1)

embeddings = []
labels = []

for speaker_dir in sorted(os.listdir(AUDIO_DIR)):
    speaker_path = os.path.join(AUDIO_DIR, speaker_dir)
    if not os.path.isdir(speaker_path):
        continue

    for wav in sorted(os.listdir(speaker_path)):
        if wav.endswith('.wav'):
            file_path = os.path.join(speaker_path, wav)
            print(f"Processing {file_path}")
            mel_input = preprocess_audio(file_path)
            embedding = model.predict(mel_input, verbose=0)[0]

            if np.isnan(embedding).any():
                print(f"⚠️ Skipping {file_path} — NaN in embedding.")
                continue

            embeddings.append(embedding)
            labels.append(speaker_dir)

# Save only valid embeddings
np.save(OUTPUT_EMBEDDINGS, np.array(embeddings))
np.save(OUTPUT_LABELS, np.array(labels))
print(f"✅ Saved {len(labels)} clean embeddings to {OUTPUT_EMBEDDINGS}")
