import sounddevice as sd
import librosa
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from tensorflow.keras.models import load_model
import tensorflow as tf
import os

# ============================
# CONFIGURATION
# ============================

SAMPLE_RATE = 16000
DURATION = 6  # seconds
MODEL_PATH = 'speaker_embedding_model.h5'
REFERENCE_EMBEDDINGS_PATH = 'reference_embeddings.npy'
REFERENCE_LABELS_PATH = 'reference_labels.npy'
TARGET_SHAPE = (128, 128)

# ============================
# LOAD MODEL AND REFERENCES
# ============================

model = load_model(MODEL_PATH, compile=False)

reference_embeddings = np.load(REFERENCE_EMBEDDINGS_PATH)
reference_labels = np.load(REFERENCE_LABELS_PATH)

assert not np.isnan(reference_embeddings).any(), "❌ Reference embeddings contain NaNs."

# ============================
# AUDIO UTILS
# ============================

def record_audio(duration=DURATION, sr=SAMPLE_RATE):
    print("🎙️ Recording...")
    audio = sd.rec(int(duration * sr), samplerate=sr, channels=1, dtype='float32')
    sd.wait()
    print("✅ Recording finished.")
    return audio.flatten()

def preprocess_audio(audio, sr=SAMPLE_RATE):
    mel = librosa.feature.melspectrogram(y=audio, sr=sr, n_fft=1024, hop_length=256, n_mels=128)
    mel_db = librosa.power_to_db(mel, ref=np.max)

    # Normalize [0, 1] safely
    mel_min = mel_db.min()
    mel_max = mel_db.max()
    mel_range = mel_max - mel_min if mel_max > mel_min else 1e-9
    mel_norm = (mel_db - mel_min) / mel_range

    mel_expanded = np.expand_dims(mel_norm, axis=-1)  # (128, time, 1)
    mel_resized = tf.image.resize(mel_expanded, TARGET_SHAPE).numpy()  # (128, 128, 1)
    return np.expand_dims(mel_resized, axis=0)  # (1, 128, 128, 1)

# ============================
# INFERENCE
# ============================

def identify_speaker():
    audio = record_audio()
    mel_input = preprocess_audio(audio)

    embedding = model.predict(mel_input, verbose=0)[0]

    if np.isnan(embedding).any():
        print("❌ Embedding contains NaNs. Skipping.")
        return

    similarities = cosine_similarity([embedding], reference_embeddings)[0]
    best_index = int(np.argmax(similarities))
    best_match = reference_labels[best_index]
    confidence = float(similarities[best_index])

    print(f"\n🔊 Detected Speaker: {best_match} (Confidence: {confidence:.2f})")

# ============================
# MAIN LOOP
# ============================

if __name__ == "__main__":
    while True:
        try:
            identify_speaker()
        except Exception as e:
            print(f"⚠️ Error: {e}")
        cont = input("\nPress [Enter] to continue or type 'q' to quit: ")
        if cont.lower() == 'q':
            break
