import librosa
import numpy as np
import matplotlib.pyplot as plt

# Load uploaded audio file
file_path = "/Users/apple/Desktop/speaker_model/audio_data/vidit/record (1).wav"
signal, sr = librosa.load(file_path, sr=16000)

# Display basic properties
duration = len(signal) / sr
max_amplitude = np.max(np.abs(signal))

# Compute mel spectrogram
mel = librosa.feature.melspectrogram(y=signal, sr=sr, n_mels=128)
mel_db = librosa.power_to_db(mel, ref=np.max)

mel_shape = mel_db.shape

# Plot waveform and mel spectrogram
plt.figure(figsize=(12, 6))

plt.subplot(2, 1, 1)
plt.title("Waveform")
plt.plot(signal)
plt.xlabel("Samples")
plt.ylabel("Amplitude")

plt.subplot(2, 1, 2)
librosa.display.specshow(mel_db, sr=sr, x_axis='time', y_axis='mel')
plt.title("Mel Spectrogram (dB)")
plt.colorbar(format="%+2.0f dB")
plt.tight_layout()

plt.show()

(duration, max_amplitude, mel_shape)
