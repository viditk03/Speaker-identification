import numpy as np
from flask import Flask, request, jsonify, render_template
from tensorflow.keras.models import load_model
from sklearn.metrics.pairwise import cosine_similarity
import librosa
import io
from pydub import AudioSegment

app = Flask(__name__)

# Config
SAMPLE_RATE = 16000
MODEL_PATH = 'speaker_embedding_model.h5'
REFERENCE_EMBEDDINGS_PATH = 'reference_embeddings.npy'
REFERENCE_LABELS_PATH = 'reference_labels.npy'
SIMILARITY_THRESHOLD = 0.7

# Load model and references
model = load_model(MODEL_PATH, compile=False)
reference_embeddings = np.load(REFERENCE_EMBEDDINGS_PATH)
reference_labels = np.load(REFERENCE_LABELS_PATH)

def extract_melspectrogram(audio, sr=16000, n_mels=128, n_fft=512, hop_length=160):
    mel_spec = librosa.feature.melspectrogram(y=audio, sr=sr, n_fft=n_fft,
                                              hop_length=hop_length, n_mels=n_mels)
    mel_spec_db = librosa.power_to_db(mel_spec, ref=np.max)
    mel_spec_db = librosa.util.fix_length(mel_spec_db, size=128, axis=1)
    mel_spec_db = (mel_spec_db - np.mean(mel_spec_db)) / (np.std(mel_spec_db) + 1e-6)
    return np.expand_dims(mel_spec_db, axis=-1)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/identify', methods=['POST'])
def identify():
    try:
        # Step 1: Get uploaded audio file from FormData
        if 'audio' not in request.files:
            return jsonify({'error': 'No audio file part in the request'}), 400

        file = request.files['audio']
        if file.filename == '':
            return jsonify({'error': 'No selected audio file'}), 400

        audio_buffer = io.BytesIO(file.read())

        # Step 2: Decode with pydub
        try:
            audio_segment = AudioSegment.from_file(audio_buffer)
        except Exception:
            audio_buffer.seek(0)
            audio_segment = AudioSegment.from_file(audio_buffer, format='wav')

        # Step 3: Mono + sample rate fix
        audio_segment = audio_segment.set_channels(1).set_frame_rate(SAMPLE_RATE)

        if len(audio_segment) < 1000:
            return jsonify({'error': 'Audio too short or invalid'}), 400

        # Step 4: Convert to numpy float32
        samples = np.array(audio_segment.get_array_of_samples()).astype(np.float32)
        if audio_segment.sample_width == 2:  # 16-bit PCM
            samples /= 32768.0

        # Step 5: Feature extraction
        mel_spec = extract_melspectrogram(samples, sr=SAMPLE_RATE)
        input_tensor = np.expand_dims(mel_spec, axis=0)

        # Step 6: Inference + similarity
        embedding = model.predict(input_tensor, verbose=0)[0]
        similarities = cosine_similarity([embedding], reference_embeddings)[0]

        best_idx = np.argmax(similarities)
        best_label = reference_labels[best_idx]
        confidence = similarities[best_idx]

        label = best_label if confidence >= SIMILARITY_THRESHOLD else "Unknown"

        return jsonify({'speaker': label, 'confidence': float(confidence)})

    except Exception as e:
        return jsonify({'error': 'Failed to process audio: ' + str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True)
