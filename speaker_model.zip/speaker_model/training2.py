import os
import random
import logging
import numpy as np
import tensorflow as tf
import tensorflow_addons as tfa
import librosa
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
import soundfile as sf
import pickle

# ====== Logging & Config =======
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

DATA_PATH = "/Users/apple/Desktop/speaker_model/audio_data"
SAMPLE_RATE = 16000
DURATION = 6
SAMPLES_PER_TRACK = SAMPLE_RATE * DURATION
BATCH_SIZE = 16
EPOCHS = 60
EMBEDDING_DIM = 192
TARGET_SHAPE = (128, 128)
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

# ====== Audio Augmentation =======
def augment_audio(signal):
    if random.random() < 0.5:
        noise_amp = 0.005 * np.random.uniform() * np.amax(signal)
        signal += noise_amp * np.random.normal(size=signal.shape[0])
    if random.random() < 0.5:
        shift = np.random.randint(-int(0.1 * SAMPLE_RATE), int(0.1 * SAMPLE_RATE))
        signal = np.roll(signal, shift)
    if random.random() < 0.3:
        factor = np.random.uniform(0.7, 1.3)
        signal *= factor
    return np.clip(signal, -1, 1)

# ====== Mel-Spectrogram Extraction =======
def extract_mel_spectrogram(signal):
    mel = librosa.feature.melspectrogram(y=signal, sr=SAMPLE_RATE, n_fft=1024, hop_length=256, n_mels=128)
    mel_db = librosa.power_to_db(mel, ref=np.max)
    mel_norm = (mel_db - mel_db.min()) / (mel_db.max() - mel_db.min() + 1e-9)
    mel_expanded = np.expand_dims(mel_norm, axis=-1)
    mel_resized = tf.image.resize(mel_expanded, TARGET_SHAPE).numpy()
    return mel_resized

# ====== Dataset Loading =======
def load_dataset(data_path=DATA_PATH, augment=True):
    X, y = [], []
    labels = sorted(os.listdir(data_path))
    for label in labels:
        folder = os.path.join(data_path, label)
        if not os.path.isdir(folder):
            continue
        for f in os.listdir(folder):
            if not f.endswith('.wav'):
                continue
            file_path = os.path.join(folder, f)
            signal, sr = librosa.load(file_path, sr=SAMPLE_RATE)
            if len(signal) < SAMPLES_PER_TRACK:
                signal = np.pad(signal, (0, SAMPLES_PER_TRACK - len(signal)))
            else:
                signal = signal[:SAMPLES_PER_TRACK]
            if augment:
                signal = augment_audio(signal)
            mel = extract_mel_spectrogram(signal)
            X.append(mel)
            y.append(label)
    X = np.array(X)
    y = np.array(y)
    le = LabelEncoder()
    y_encoded = le.fit_transform(y)
    return train_test_split(X, y_encoded, test_size=0.25, random_state=SEED, stratify=y_encoded), le

def create_dataset(X, y, batch_size):
    return tf.data.Dataset.from_tensor_slices((X, y)) \
        .shuffle(buffer_size=1024) \
        .batch(batch_size) \
        .prefetch(tf.data.AUTOTUNE)

# ====== Residual CNN Model =======
def residual_block(x, filters):
    res = x
    x = tf.keras.layers.Conv2D(filters, 3, padding='same')(x)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.ReLU()(x)
    x = tf.keras.layers.Conv2D(filters, 3, padding='same')(x)
    x = tf.keras.layers.BatchNormalization()(x)
    if res.shape[-1] != filters:
        res = tf.keras.layers.Conv2D(filters, 1, padding='same')(res)
    x = tf.keras.layers.Add()([x, res])
    x = tf.keras.layers.ReLU()(x)
    return x

def build_speaker_embedding_model(input_shape=(128, 128, 1), embedding_dim=EMBEDDING_DIM):
    inputs = tf.keras.Input(shape=input_shape)
    x = tf.keras.layers.Conv2D(64, 3, padding='same', activation='relu')(inputs)
    x = residual_block(x, 64)
    x = tf.keras.layers.MaxPooling2D(2)(x)
    x = residual_block(x, 128)
    x = tf.keras.layers.MaxPooling2D(2)(x)
    x = residual_block(x, 256)
    x = tf.keras.layers.GlobalAveragePooling2D()(x)
    x = tf.keras.layers.Dense(embedding_dim)(x)
    x = tf.keras.layers.Lambda(lambda t: tf.math.l2_normalize(t, axis=1))(x)
    return tf.keras.Model(inputs, x)

# ====== Triplet Loss Trainer =======
class SpeakerModel(tf.keras.Model):
    def __init__(self, embedding_model, margin=0.3):
        super().__init__()
        self.embedding_model = embedding_model
        self.loss_fn = tfa.losses.TripletSemiHardLoss(margin=margin)
        self.train_loss_tracker = tf.keras.metrics.Mean(name="train_loss")
        self.val_loss_tracker = tf.keras.metrics.Mean(name="val_loss")

    def compile(self, optimizer):
        super().compile()
        self.optimizer = optimizer

    def train_step(self, data):
        x, y = data
        with tf.GradientTape() as tape:
            embeddings = self.embedding_model(x, training=True)
            loss = self.loss_fn(y, embeddings)
        grads = tape.gradient(loss, self.embedding_model.trainable_variables)
        self.optimizer.apply_gradients(zip(grads, self.embedding_model.trainable_variables))
        self.train_loss_tracker.update_state(loss)
        return {"loss": self.train_loss_tracker.result()}

    def test_step(self, data):
        x, y = data
        embeddings = self.embedding_model(x, training=False)
        loss = self.loss_fn(y, embeddings)
        self.val_loss_tracker.update_state(loss)
        return {"val_loss": self.val_loss_tracker.result()}

# ====== Main Training Function =======
def main_train():
    (X_train, X_test, y_train, y_test), label_encoder = load_dataset(augment=True)
    logging.info(f"Loaded data: train={len(X_train)}, test={len(X_test)}, speakers={len(label_encoder.classes_)}")

    train_dataset = create_dataset(X_train, y_train, BATCH_SIZE)
    test_dataset = create_dataset(X_test, y_test, BATCH_SIZE)

    embedding_model = build_speaker_embedding_model()
    speaker_model = SpeakerModel(embedding_model)
    speaker_model.compile(optimizer=tf.keras.optimizers.Adam(1e-3))

    speaker_model.fit(
        train_dataset,
        validation_data=test_dataset,
        epochs=EPOCHS,
        callbacks=[
            tf.keras.callbacks.EarlyStopping(patience=7, restore_best_weights=True),
            tf.keras.callbacks.ReduceLROnPlateau(patience=3),
            tf.keras.callbacks.TensorBoard(log_dir="./logs", histogram_freq=1)
        ]
    )

    embedding_model.save("speaker_embedding_model.h5")
    with open("label_encoder.pkl", "wb") as f:
        pickle.dump(label_encoder, f)
    logging.info("Model and LabelEncoder saved.")

if __name__ == "__main__":
    main_train()
