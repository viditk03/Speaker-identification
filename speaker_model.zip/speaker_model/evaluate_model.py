import os
import numpy as np
import librosa
import tensorflow as tf
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
import matplotlib.pyplot as plt
from tqdm import tqdm

# Load model
model = tf.keras.models.load_model("/Users/apple/Desktop/speaker_model/Model.keras", compile=False)

# Config
SAMPLE_RATE = 16000
DURATION = 2
EXPECTED_SAMPLES = SAMPLE_RATE * DURATION
N_MELS = 40

# Data folders (one per speaker)
DATA_DIR = "/Users/apple/Desktop/speaker_model/audio_data"
speakers = sorted(os.listdir(DATA_DIR)) 

# Extract embedding function
def extract_embedding_from_file(file_path):
    audio, sr = librosa.load(file_path, sr=SAMPLE_RATE)
    if len(audio) < EXPECTED_SAMPLES:
        audio = np.pad(audio, (0, EXPECTED_SAMPLES - len(audio)))
    else:
        audio = audio[:EXPECTED_SAMPLES]
    mel = librosa.feature.melspectrogram(y=audio, sr=sr, n_mels=N_MELS)
    mel_db = librosa.power_to_db(mel, ref=np.max)
    mel_db = (mel_db - mel_db.mean()) / mel_db.std()
    mel_db = np.expand_dims(mel_db, axis=-1)
    mel_db = np.expand_dims(mel_db, axis=0)
    embedding = model.predict(mel_db)
    return embedding[0]

# Compute reference embeddings
reference_embeddings = {}
for speaker in speakers:
    files = os.listdir(os.path.join(DATA_DIR, speaker))
    emb_list = []
    for file in files[:3]:  # first 3 files for reference
        emb = extract_embedding_from_file(os.path.join(DATA_DIR, speaker, file))
        emb_list.append(emb)
    reference_embeddings[speaker] = np.mean(emb_list, axis=0)

# Evaluate using remaining files
y_true = []
y_pred = []

for speaker in speakers:
    files = os.listdir(os.path.join(DATA_DIR, speaker))
    for file in tqdm(files[3:]):  # remaining files for test
        test_emb = extract_embedding_from_file(os.path.join(DATA_DIR, speaker, file))
        similarities = {
            ref_speaker: np.dot(test_emb, ref_emb) / (np.linalg.norm(test_emb) * np.linalg.norm(ref_emb))
            for ref_speaker, ref_emb in reference_embeddings.items()
        }
        pred = max(similarities, key=similarities.get)
        y_true.append(speaker)
        y_pred.append(pred)

# Confusion matrix
cm = confusion_matrix(y_true, y_pred, labels=speakers)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=speakers)
disp.plot(cmap='Blues', xticks_rotation=45)
plt.title("Confusion Matrix - Speaker Identification")
plt.show()
